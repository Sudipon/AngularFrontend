import { Userloginfo } from './userloginfo.model';

describe('Userloginfo', () => {
  it('should create an instance', () => {
    expect(new Userloginfo()).toBeTruthy();
  });
});
