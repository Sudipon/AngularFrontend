export interface Contacts{
    id: string,
    title: string,
    mobile:string
    body: string,
    email: string,
    name: string,
    createdAt: Date,
    isSolved: boolean
}