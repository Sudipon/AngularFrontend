import { Contactinfo } from './contactinfo.model';

describe('Contactinfo', () => {
  it('should create an instance', () => {
    expect(new Contactinfo()).toBeTruthy();
  });
});
