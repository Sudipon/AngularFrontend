export class Contactinfo {
}
