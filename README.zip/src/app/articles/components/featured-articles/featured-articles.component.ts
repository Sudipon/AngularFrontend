import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-featured-articles',
  templateUrl: './featured-articles.component.html',
  styleUrls: ['./featured-articles.component.css']
})
export class FeaturedArticlesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
