import { Articles } from './articles.model';

describe('Articles', () => {
  it('should create an instance', () => {
    expect(new Articles()).toBeTruthy();
  });
});
